import React from 'react'

const AddData = () => {
    return (
        <div>AddData</div>
    )
}

export default AddData