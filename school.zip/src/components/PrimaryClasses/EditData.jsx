import React from 'react'

const EditData = () => {
    return (
        <div>EditData</div>
    )
}

export default EditData