import React from 'react'

const UserData = () => {
    return (
        <div>UserData</div>
    )
}

export default UserData